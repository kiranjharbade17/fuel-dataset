CREATE DATABASE  fuel_db;
USE fuel_db;

CREATE TABLE fuel_prices_raw (
    `date`            VARCHAR(20),
    country           VARCHAR(100),
    region            VARCHAR(100),
    income_level      VARCHAR(20),
    subsidy_level     VARCHAR(20),
    petrol_usd_liter  DECIMAL(8,3),
    diesel_usd_liter  DECIMAL(8,3),
    lpg_usd_liter     DECIMAL(8,3),
    brent_crude_usd   DECIMAL(10,3),
    tax_percentage    DECIMAL(6,1)
);
select*from global_fuel_prices_dataset;
USE fuel_db;
DROP TABLE IF EXISTS fuel_prices_raw;

SELECT COUNT(*) FROM global_fuel_prices_dataset;
SELECT * FROM global_fuel_prices_dataset LIMIT 5;

USE fuel_db;
DROP TABLE IF EXISTS fuel_clean;

CREATE TABLE fuel_clean AS
SELECT
    STR_TO_DATE(TRIM(`date`), '%Y-%m-%d')        AS price_date,
    YEAR(STR_TO_DATE(TRIM(`date`), '%Y-%m-%d'))  AS price_year,
    TRIM(country)  AS country,
    TRIM(region)   AS region,
    TRIM(income_level)  AS income_level,
    TRIM(subsidy_level) AS subsidy_level,
    petrol_usd_liter, diesel_usd_liter, lpg_usd_liter,
    brent_crude_usd, tax_percentage
FROM global_fuel_prices_dataset;

select*from fuel_clean;

SELECT COUNT(*) AS total_rows, SUM(price_date IS NULL) AS bad_dates
FROM fuel_clean;
