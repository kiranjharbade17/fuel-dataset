# Tableau build guide — global fuel pricing views

## Connect and prepare
Connect Tableau to `data/global_fuel_prices_Dataset.csv`. Set `Date` to Date, numeric fields to measures, and `Country`, `Region`, `Income Level`, and `Subsidy Level` to dimensions. Keep the source fields; do not add calculated columns or Tableau calculated fields. Use standard aggregations such as AVG and COUNTD.

## Interactive filters
Add these dashboard filters and apply them to relevant worksheets:

- **Country** — select from 84 countries.
- **Measure Names** — select Petrol, Diesel, and LPG for the multi-fuel comparison. Brent Crude has a different scale and should be shown in its own trend view.
- **Year** — support year-over-year comparison. Label 2026 as partial through April 6.

The saved workbook currently has five starter views and these dashboard filters are not yet configured.

## Visualization list
The project description says “9 distinct visualization types” but enumerates ten view entries. This guide preserves all ten entries, grouped into five chart families (KPI cards, maps, line charts, pie chart, and bar charts).

1. **KPI cards — global fuel price indicators:** show average Petrol, Diesel, and LPG prices, plus average Tax Percentage, using existing measures.
2. **Geospatial heat map — petrol:** Country filled map colored by average Petrol price.
3. **Geospatial heat map — diesel:** Country filled map colored by average Diesel price.
4. **Trend line — petrol:** Date by week or year against average Petrol price, 2020–2026.
5. **Trend line — diesel:** Date by week or year against average Diesel price, 2020–2026.
6. **Trend line — LPG:** Date by week or year against average LPG price, 2020–2026.
7. **Trend line — Brent Crude:** Date by week or year against the source Brent Crude measure, 2020–2026. The source does not specify the crude measure's unit; confirm it before labeling the axis.
8. **Pie chart — average tax by region:** Region as the category and average Tax Percentage as the measure. Label values and note that the view compares regional averages.
9. **Bar chart — highest tax-paying nations:** rank countries by average Tax Percentage and show the top 10 by default. Use a Tableau Top filter on the existing Country dimension and average Tax measure.
10. **Bar chart — fuel comparison among the top 3 countries:** identify the top three countries by average Petrol price, then compare their average Petrol, Diesel, and LPG prices using Measure Names. State the ranking basis in the chart subtitle.

## Layout and interaction
Place KPI cards across the top. Arrange both maps side by side, followed by the four trend charts, the tax pie, and the two comparison bars. Add Country, Measure Names, and Year filters. Keep chart titles and tooltips explicit about units and aggregation. Add the note: “Associations are descriptive; this data does not establish causal effects or household affordability.”

## Data volume and performance context
The project description reports approximately 2.7 MB loaded into Tableau and says the complete interactive dashboard renders within acceptable time limits and remains responsive when users apply multiple filters. Treat this as reported project context: the saved workbook is a five-view starter and has not been evaluated as this completed dashboard. The source CSV file is approximately 1.9 MB on disk.

## Tableau Story
Create seven story points: Introduction, Geographic Disparity, Temporal Trends, Taxation Policy, Economic Impact, Subsidy Assessment, and Conclusions and Recommendations. Use captions from `project_story.md` and retain the caveats in the relevant story points.
