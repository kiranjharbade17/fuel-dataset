import csv
import os
from pathlib import Path
from urllib.parse import urlparse

from flask import Flask, jsonify, render_template

app = Flask(__name__)
PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = PROJECT_ROOT / "data" / "global_fuel_prices_Dataset.csv"
ALLOWED_TABLEAU_HOSTS = {"public.tableau.com", "www.public.tableau.com"}


def tableau_public_url(env_name: str) -> str | None:
    value = os.environ.get(env_name, "").strip()
    if not value:
        return None
    parsed = urlparse(value)
    if parsed.scheme != "https" or parsed.hostname not in ALLOWED_TABLEAU_HOSTS:
        return None
    return value


def load_records():
    numeric_fields = {
        "petrol_usd_liter", "diesel_usd_liter", "lpg_usd_liter",
        "brent_crude_usd", "tax_percentage",
    }
    with DATA_PATH.open("r", encoding="utf-8-sig", newline="") as source:
        records = []
        for row in csv.DictReader(source):
            for field in numeric_fields:
                row[field] = float(row[field])
            records.append(row)
    return records


@app.get("/")
def home():
    return render_template(
        "index.html",
        dashboard_url=tableau_public_url("TABLEAU_DASHBOARD_URL"),
        story_url=tableau_public_url("TABLEAU_STORY_URL"),
    )


@app.get("/api/data")
def data():
    return jsonify(load_records())


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", "5000")), debug=False)
