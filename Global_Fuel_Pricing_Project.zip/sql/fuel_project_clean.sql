CREATE DATABASE IF NOT EXISTS fuel_db;
USE fuel_db;

-- Run from the project root and enable LOCAL INFILE in the MySQL client/server.
DROP TABLE IF EXISTS global_fuel_prices_dataset;
CREATE TABLE global_fuel_prices_dataset (
    `date` DATE NOT NULL,
    country VARCHAR(100) NOT NULL,
    region VARCHAR(100) NOT NULL,
    income_level VARCHAR(30) NOT NULL,
    subsidy_level VARCHAR(30) NOT NULL,
    petrol_usd_liter DECIMAL(8,3) NOT NULL,
    diesel_usd_liter DECIMAL(8,3) NOT NULL,
    lpg_usd_liter DECIMAL(8,3) NOT NULL,
    brent_crude_usd DECIMAL(12,3) NOT NULL,
    tax_percentage DECIMAL(6,1) NOT NULL,
    PRIMARY KEY (`date`, country)
);

LOAD DATA LOCAL INFILE 'data/global_fuel_prices_Dataset.csv'
INTO TABLE global_fuel_prices_dataset
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES
(`date`, country, region, income_level, subsidy_level,
 petrol_usd_liter, diesel_usd_liter, lpg_usd_liter,
 brent_crude_usd, tax_percentage);

DROP TABLE IF EXISTS fuel_clean;
CREATE TABLE fuel_clean AS
SELECT `date`,
       TRIM(country) AS country, TRIM(region) AS region,
       TRIM(income_level) AS income_level, TRIM(subsidy_level) AS subsidy_level,
       petrol_usd_liter, diesel_usd_liter, lpg_usd_liter,
       brent_crude_usd, tax_percentage
FROM global_fuel_prices_dataset;

SELECT COUNT(*) AS total_rows, COUNT(DISTINCT country) AS countries,
       COUNT(DISTINCT `date`) AS dates
FROM fuel_clean;

SELECT COUNT(*) AS duplicate_date_country_keys
FROM (
    SELECT `date`, country FROM fuel_clean
    GROUP BY `date`, country HAVING COUNT(*) > 1
) AS duplicates;

SELECT MIN(`date`) AS first_date, MAX(`date`) AS last_date,
       SUM(`date` IS NULL) AS bad_dates
FROM fuel_clean;


