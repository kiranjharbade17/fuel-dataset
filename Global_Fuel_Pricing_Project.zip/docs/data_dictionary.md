# Data dictionary

| Field | Meaning | Notes |
|---|---|---|
| `date` | Weekly observation date | ISO YYYY-MM-DD; source file grouped by country |
| `country` | Country name | 84 distinct countries |
| `region` | World region | 7 categories; stable within country in this file |
| `income_level` | Country income category | High, Middle, Low; stable within country |
| `subsidy_level` | Subsidy category | Low, Medium, High, Very High; stable within country |
| `petrol_usd_liter` | Petrol price, USD/liter | Observed range 0.010–6.779 |
| `diesel_usd_liter` | Diesel price, USD/liter | Observed range 0.010–6.240 |
| `lpg_usd_liter` | LPG price, USD/liter | Observed range 0.010–5.100 |
| `brent_crude_usd` | Brent crude price measure | Column does not specify a per-barrel unit; confirm before interpretation |
| `tax_percentage` | Tax percentage | Observed range 0–65; denominator/definition not specified |

## Grain and limits
One row per country per week: 27,468 rows, 84 countries, 327 dates per country. No blanks or duplicate date-country keys were found. Observed numeric ranges are not automatically valid ranges; confirm extreme values against documentation. The CSV does not prove that outliers were independently validated or region mappings checked against an authoritative source. Country income categories are not household income. There are no household fuel spending, exchange rate, or purchasing-power measures, so affordability and causal policy effects cannot be established.

## Preparation note
The analysis uses the source dataset's existing columns; no additional calculated columns or Tableau calculated fields were created. Standard aggregations in visualizations summarize existing measures.
