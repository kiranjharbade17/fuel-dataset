const COLORS = {petrol:'#176e67', diesel:'#cb7358', lpg:'#d8a958', brent:'#487a8e', grid:'#e8ece6', text:'#718078'};
const FIELDS = {petrol:'petrol_usd_liter',diesel:'diesel_usd_liter',lpg:'lpg_usd_liter',brent:'brent_crude_usd'};
let records = [];
const el = (id) => document.getElementById(id);
const mean = (rows, field) => rows.length ? rows.reduce((sum, row) => sum + Number(row[field] || 0), 0) / rows.length : 0;
const money = (value) => Number.isFinite(value) ? '$' + value.toFixed(2) : '—';
const pct = (value) => Number.isFinite(value) ? value.toFixed(1) + '%' : '—';
const selectedMeasures = () => Array.from(el('measureFilter').selectedOptions).map(option => option.value);
const layoutBase = {paper_bgcolor:'rgba(0,0,0,0)',plot_bgcolor:'rgba(0,0,0,0)',font:{family:'Inter, Segoe UI, sans-serif',color:'#63746c',size:11},margin:{l:50,r:18,t:10,b:44},xaxis:{gridcolor:COLORS.grid,zerolinecolor:COLORS.grid},yaxis:{gridcolor:COLORS.grid,zerolinecolor:COLORS.grid},hoverlabel:{bgcolor:'#173d3a',font:{color:'#fff'}}};
const config = {responsive:true,displayModeBar:false,scrollZoom:false};
function draw(id, data, layout={}) { if (!window.Plotly) return; Plotly.react(id,data,{...layoutBase,...layout},{...config}); }
function aggregate(rows, keyFn, field) {
  const buckets = new Map();
  rows.forEach(row => { const key=keyFn(row); if(!buckets.has(key)) buckets.set(key,[]); buckets.get(key).push(row); });
  return Array.from(buckets,([key,items])=>({key,value:mean(items,field),count:items.length}));
}
function setupFilters() {
  const countries=[...new Set(records.map(row=>row.country))].sort((a,b)=>a.localeCompare(b));
  countries.forEach(country=>{const option=document.createElement('option');option.value=country;option.textContent=country;el('countryFilter').append(option);});
  for(let year=2020;year<=2026;year++){for(const id of ['yearFrom','yearTo']){const option=document.createElement('option');option.value=year;option.textContent=year;el(id).append(option);}}
  el('yearFrom').value='2020'; el('yearTo').value='2026';
}
function filteredRows() {
  const country=el('countryFilter').value, from=Number(el('yearFrom').value), to=Number(el('yearTo').value);
  return records.filter(row=>{const year=Number(row.date.slice(0,4));return (country==='all'||row.country===country)&&year>=from&&year<=to;});
}
function update() {
  const rows=filteredRows();
  if(!rows.length){el('status').textContent='No rows match the current selections.';return;}
  el('status').textContent=`Showing ${rows.length.toLocaleString()} weekly records · ${new Set(rows.map(row=>row.country)).size} countries · ${el('yearFrom').value}–${el('yearTo').value}`;
  el('kpiPetrol').textContent=money(mean(rows,FIELDS.petrol)); el('kpiDiesel').textContent=money(mean(rows,FIELDS.diesel));
  el('kpiLpg').textContent=money(mean(rows,FIELDS.lpg)); el('kpiTax').textContent=pct(mean(rows,'tax_percentage'));
  drawMap(rows,'petrolMap',FIELDS.petrol,'Average petrol price');
  drawMap(rows,'dieselMap',FIELDS.diesel,'Average diesel price');
  drawTrend(rows,'petrolTrend',FIELDS.petrol,COLORS.petrol);
  drawTrend(rows,'dieselTrend',FIELDS.diesel,COLORS.diesel);
  drawTrend(rows,'lpgTrend',FIELDS.lpg,COLORS.lpg);
  drawTrend(rows,'brentTrend',FIELDS.brent,COLORS.brent);
  const regions=aggregate(rows,row=>row.region,'tax_percentage').sort((a,b)=>b.value-a.value);
  draw('taxPie',[{type:'pie',labels:regions.map(item=>item.key),values:regions.map(item=>item.value),hole:.48,sort:false,textinfo:'label+percent',textposition:'outside',marker:{colors:['#176e67','#d8a958','#cb7358','#5b8790','#93b19d','#c18c75','#78927c'],line:{color:'#fff',width:2}},hovertemplate:'%{label}<br>Average tax: %{value:.1f}%<extra></extra>'}],{showlegend:false,margin:{l:28,r:28,t:20,b:25}});
  const topTax=aggregate(rows,row=>row.country,'tax_percentage').sort((a,b)=>b.value-a.value).slice(0,10).reverse();
  draw('taxTop',[{type:'bar',orientation:'h',y:topTax.map(item=>item.key),x:topTax.map(item=>item.value),marker:{color:topTax.map((_,i)=>i>6?COLORS.petrol:'#9cbdb1')},hovertemplate:'%{y}<br>Average tax: %{x:.1f}%<extra></extra>'}],{margin:{l:130,r:20,t:8,b:42},xaxis:{...layoutBase.xaxis,title:'Average tax (%)'},yaxis:{...layoutBase.yaxis,gridcolor:'rgba(0,0,0,0)'},showlegend:false});
  drawTopFuel(rows);
}
function drawMap(rows,id,field,label) {
  const countries=aggregate(rows,row=>row.country,field);
  draw(id,[{type:'choropleth',locationmode:'country names',locations:countries.map(item=>item.key),z:countries.map(item=>item.value),text:countries.map(item=>item.key),colorscale:[[0,'#e8eee7'],[.35,'#9fc5b4'],[.7,'#3b8b7f'],[1,'#174a47']],marker:{line:{color:'#f8faf7',width:.35}},colorbar:{thickness:10,len:.65,tickfont:{size:9}},hovertemplate:'%{location}<br>'+label+': $%{z:.2f}<extra></extra>'}],{geo:{showframe:false,showcoastlines:false,showland:true,landcolor:'#edf0eb',bgcolor:'rgba(0,0,0,0)',projection:{type:'natural earth'}},margin:{l:0,r:0,t:0,b:0}});
}
function drawTrend(rows,id,field,color) {
  const series=aggregate(rows,row=>row.date.slice(0,7),field).sort((a,b)=>a.key.localeCompare(b.key));
  draw(id,[{type:'scatter',mode:'lines',x:series.map(item=>item.key),y:series.map(item=>item.value),line:{color,width:2.5},fill:'tozeroy',fillcolor:color+'18',hovertemplate:'%{x}<br>$%{y:.2f}<extra></extra>'}],{margin:{l:55,r:14,t:10,b:45},xaxis:{...layoutBase.xaxis,tickangle:-20,nticks:7},yaxis:{...layoutBase.yaxis,title:'Average price'}});
}
function drawTopFuel(rows) {
  const chosen=selectedMeasures();
  const top=aggregate(rows,row=>row.country,FIELDS.petrol).sort((a,b)=>b.value-a.value).slice(0,3);
  const traces=chosen.map((measure,index)=>{const field=FIELDS[measure];return {type:'bar',name:measure[0].toUpperCase()+measure.slice(1),x:top.map(item=>item.key),y:top.map(item=>mean(rows.filter(row=>row.country===item.key),field)),marker:{color:[COLORS.petrol,COLORS.diesel,COLORS.lpg][['petrol','diesel','lpg'].indexOf(measure)]||['#176e67','#cb7358','#d8a958'][index]},hovertemplate:'%{x}<br>'+measure+': $%{y:.2f}<extra></extra>'};});
  draw('topFuel',traces,{barmode:'group',margin:{l:58,r:20,t:10,b:80},xaxis:{...layoutBase.xaxis,tickangle:-14},yaxis:{...layoutBase.yaxis,title:'USD / liter'},legend:{orientation:'h',y:1.12,x:0}});
}
function init() {
  fetch('/api/data').then(response=>{if(!response.ok)throw new Error('Dataset could not be loaded');return response.json();}).then(data=>{
    records=data; setupFilters();
    for(const id of ['countryFilter','yearFrom','yearTo','measureFilter']) el(id).addEventListener('change',(e)=>{if(Number(el('yearFrom').value)>Number(el('yearTo').value)){if(e.target.id==='yearFrom')el('yearTo').value=el('yearFrom').value;else el('yearFrom').value=el('yearTo').value;}update();});
    el('resetFilters').addEventListener('click',()=>{el('countryFilter').value='all';el('yearFrom').value='2020';el('yearTo').value='2026';for(const option of el('measureFilter').options)option.selected=true;update();});
    update();
  }).catch(error=>{el('status').textContent=error.message+'. Start the Flask app from the web folder and ensure the CSV is present.';});
}
window.addEventListener('DOMContentLoaded',init);

