# SkillWallet project process and local status

Source: [SkillWallet project brief](https://myskillwallet.ai/dashboard/skillwallet/module/data-analytics-with-tableau-6abcea54500f0d3aeede3da2/projects/6aba31f35015c35b9863f807/Global-Fuel-Prices-and-Taxation-Trends-A-Comprehensive-Global-Performance-Intelligence-Report-6ace830274837db2f7715373?tab=3), inspected 2026-10-20.

## Project goal and audience
Build an intelligence report on global fuel pricing and taxation, for an energy policy consultant, global supply-chain manager, and energy-economics researcher. The process asks for data acquisition and SQL, data preparation, visualizations, an interactive dashboard, a Tableau Story, performance checks, Flask web integration, and final documentation/demo.

## Local deliverables and status

| Process stage | Status | Evidence / next step |
|---|---|---|
| Define problem and research question | Prepared | See `project_story.md`. |
| Collect dataset | Complete | Full 27,468-row CSV is in `data/`. |
| Database and SQL workflow | Prepared, not executed | Import and quality-check script is in `sql/fuel_project_clean.sql`; no database copy is included. |
| Connect data to Tableau | Complete via CSV | Tableau workbook reads the project CSV. Database connection is not used. |
| Prepare data | Source-level checks prepared | Missing values and duplicate country-week keys were checked. External validation of extreme values and region mappings is not documented. |
| Requested visualizations | Complete in local Flask companion; partial in Tableau | Flask page contains the requested KPI, two maps, four trends, regional tax pie, top-tax bar, and top-three fuel comparison. Tableau workbook retains five starter worksheets; build guide specifies completing the same views in Tableau. |
| Interactive filters | Complete in Flask; not complete in Tableau | Country, from/to year, and fuel-measure selectors update the Flask views. Add Country, Measure Names, and Year filters to Tableau worksheets/dashboard. |
| Dashboard | Flask dashboard complete; Tableau dashboard assembled from existing sheets | Main Tableau dashboard has five current worksheets; improve layout, replace starter views with the ten requested views, and add filters. |
| Tableau Story | Seven points saved; narrative needs alignment | Workbook now contains seven saved points and captions. It covers introduction, geography, income, regional context, taxation, temporal trend, and conclusion. The requested subsidy scene is missing, and the point order/content should be aligned to the seven-scene outline in `project_story.md`. |
| Performance | Not benchmarked | Dataset count and CSV size are recorded. Measure Tableau responsiveness and browser rendering on the finished dashboard before making performance claims. |
| Tableau Public publishing | Pending user sign-in and final workbook | Publishing instructions are in `tableau_public_publishing.md`. Add approved public view URLs only after publishing. |
| Flask integration | Local interactive report complete; Tableau embed optional | Run `py .\\web\\app.py` from the project root. Configure `TABLEAU_DASHBOARD_URL` and `TABLEAU_STORY_URL` to embed Tableau Public views after publishing. |
| Demo recording | Pending | Follow `demo_video_script.md` after the final Tableau build and publish. |
| Documentation | Prepared | Project README, data dictionary, process map, story, build guide, publishing notes, web setup and demo script are present. |

## Visualization and calculated-field decisions
The brief says “nine distinct visualization types” and lists ten view entries; this project retains all ten requested views. The analysis uses existing dataset columns and creates no calculated fields. The top-three country comparison ranks by average petrol price and compares the selected Petrol, Diesel, and LPG measures.

## SkillWallet status when inspected
The project overview displayed **12% progress**, with **8 epics** and **14 tasks**. Kanban showed **3 in progress**, **11 to do**, **0 to be reviewed**, and **0 completed**. The in-progress cards were Downloading the Dataset, Connect Dataset with Tableau, and Prepare the Data for Visualization. No SkillWallet task status was changed.

## Completion order
1. Build the remaining requested Tableau views and dashboard filters; align the seven Story scenes, including subsidy assessment.
2. Check the dashboard layout and measure load/filter response; document observed results.
3. Publish the finished workbook to Tableau Public and enter the public URLs in Flask.
4. Record the project walkthrough and update this file with final links and evidence.
5. Add the Desktop project folder to Git when ready.

