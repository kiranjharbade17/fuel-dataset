# Publish the Tableau dashboard to Tableau Public

## Status
Publishing is a final step. The local workbook currently contains five starter views; finish the planned dashboard, filters, and seven Tableau Story points before publishing.

## Prepare the workbook
1. Open `Global_Fuel_Pricing_Trends.twb` in Tableau Desktop or Tableau Public.
2. Complete and review the dashboard and story. Confirm chart titles, labels, units, filters, and tooltips.
3. Remove temporary or unused sheets and data sources that are not needed in the deliverable.
4. Decide whether the workbook should be public or hidden on your profile. Tableau Public is intended for sharing workbooks publicly; review the workbook and its data before upload.

## Sign in and publish
1. In Tableau, choose **File > Save to Tableau Public** (the exact menu label may vary by version).
2. Sign in to your Tableau Public account when prompted.
3. Enter a workbook name and choose **Save**. Tableau uploads the workbook to your profile.
4. When the published workbook opens in a browser, check that the dashboard, story points, and interactive filters display correctly.

## Share
Copy the published workbook link to share it. Tableau Public also provides options to embed the visualization in a website. Apply the intended profile visibility setting before sharing.

## Flask web app
After publishing, use the dashboard and Story URLs in the Flask app configuration described in `web/README.md`. This lets the app embed each published view in its browser page.
## Current publication status
This project has not been uploaded to Tableau Public. The `.twb` file in this folder is the local working copy.

