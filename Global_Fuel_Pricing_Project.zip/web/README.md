# Flask dashboard and Tableau embed

The Flask companion runs a local interactive dashboard directly from the supplied CSV. It includes four KPI cards, petrol and diesel world choropleths, four monthly trend charts, regional tax share, top ten tax countries, and a top three fuel comparison. Country, year range, and fuel-measure selectors update the views. It uses the existing source fields and adds no calculated columns.

## Run locally

From the project root in PowerShell:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
py -m pip install -r .\web\requirements.txt
py .\web\app.py
```

Open `http://127.0.0.1:5000`. The charts use Plotly.js from its CDN, so the browser needs internet access to load the visualization library. The data is served locally from `data/global_fuel_prices_Dataset.csv`.

## Optional Tableau Public embeds

After publishing the Tableau dashboard and Story, set the public view URLs before starting Flask:

```powershell
$env:TABLEAU_DASHBOARD_URL = "https://public.tableau.com/views/your-workbook/your-dashboard"
$env:TABLEAU_STORY_URL = "https://public.tableau.com/views/your-workbook/your-story"
py .\web\app.py
```

The app accepts HTTPS links only from `public.tableau.com` or `www.public.tableau.com`. Until those links are configured, the local CSV dashboard remains available. Do not put Tableau credentials in the project files.

## File layout

- `app.py` — Flask page and local JSON endpoint.
- `templates/index.html` — report sections and charts.
- `static/app.js` — filtering, aggregation, and Plotly rendering.
- `static/styles.css` — responsive report styling.

## Tableau references

- [Tableau Embedding API v3 basic embedding](https://help.tableau.com/current/api/embedding_api/en-us/docs/embedding_api_basic.html)
- [Configure Tableau embedded views](https://help.tableau.com/current/api/embedding_api/en-us/docs/embedding_api_configure.html)
