# Data story: global fuel pricing and policy

## Research question
How do weekly fuel prices vary across regions and over time, and how are observed prices associated with tax, country income category, and subsidy category? This is descriptive analysis; it does not estimate causal policy effects or household affordability.

## Scene 1 — Introduction: the question
Fuel prices matter to households, businesses, and governments. The dataset covers 84 countries, 7 regions, and weekly observations from 2020-01-06 to 2026-04-06. Overall means are $2.282/L petrol, $2.134/L diesel, and $1.711/L LPG.

## Scene 2 — Geographic disparity: global price variations
Europe has the highest regional mean petrol price ($3.702/L); the Middle East has the lowest ($1.226/L). Oceania is also high ($3.655/L). These means do not adjust for purchasing power or transport costs.

## Scene 3 — Temporal trends: price movements over time
Annual mean petrol price rose from $1.485/L in 2020 to $2.505/L in 2022, eased to $2.234/L in 2023, and was $2.545/L in 2024 and $2.540/L in 2025. The 2026 mean is $2.647/L through April 6, a partial year. Compare weekly fuel series; show Brent in a separate pane or selectable measure because its scale differs.

## Scene 4 — Taxation policy: global tax analysis
Country mean tax and mean petrol price have Pearson correlation around 0.836. This association does not show that taxes alone caused price differences; region, income, market structure, and other factors may also vary. Pair a country-level tax-versus-price bubble chart with tax-by-region bars.

## Scene 5 — Economic impact: income categories
Average petrol price is $3.547/L for High, $1.594/L for Middle, and $1.389/L for Low income categories. These are country-category comparisons, not household affordability estimates. Household income and fuel spending are absent.

## Scene 6 — Subsidy assessment: government support
Average petrol price is $3.451/L for Low subsidy, $1.659/L for Medium, $0.709/L for High, and $0.148/L for Very High. Prices trend lower in higher subsidy categories in this file, but the analysis cannot isolate subsidy effects from country differences.

## Scene 7 — Conclusions and recommendations
Price levels differ by region and income category. Annual means peaked in 2022, eased in 2023, and 2026 is year-to-date only. Taxes and subsidy categories are associated with prices in these records, but the data does not support causal conclusions.

Recommendations: compare taxes and subsidies alongside crude prices, exchange rates, transport costs, and market structure; add household income and fuel expenditure before making affordability claims; validate extreme values against source documentation; and label 2026 as year-to-date through April 6.
