# End-to-end demo video script

**Target length:** 4–6 minutes. Record only after the Tableau dashboard, Story, and Flask embed are complete. Do not claim steps as completed until you have verified them.

## 1. Introduction (30 seconds)
“ This project examines global fuel price and taxation trends from 2020 through April 2026. The dataset covers 84 countries across seven regions. The goal is to compare fuel price movements and explore how prices relate to taxation, income categories, and subsidy categories.”

## 2. Data and preparation (45 seconds)
Show the CSV and data dictionary. State that it contains 27,468 weekly records and 10 original columns. Demonstrate the SQL import and quality-check queries if MySQL has been run. Explain that no calculated columns were added; Year filtering uses the existing Date field and visualizations aggregate existing measures.

## 3. Visualization and dashboard (90 seconds)
Walk through the KPI cards, petrol and diesel maps, the four fuel-price trends, the regional tax pie, the highest-tax country bars, and the top-three-country fuel comparison. Show Country, Measure Names, and Year filters changing the views. Identify 2026 as partial through April 6.

## 4. Tableau Story (60 seconds)
Navigate the seven story points in order: Introduction, Geographic Disparity, Temporal Trends, Taxation Policy, Economic Impact, Subsidy Assessment, and Conclusions and Recommendations. Explain the main finding and limitation for each scene.

## 5. Performance and Flask integration (45 seconds)
Show the measured dataset/workbook size, load time, and filter response results. Then open the Flask page and demonstrate the embedded dashboard and Story. If the Tableau URLs are not configured or published, state that clearly and omit claims that the embed is live.

## 6. Conclusion (30 seconds)
Summarize the descriptive findings and recommendations. State that the observed tax and subsidy relationships are not causal estimates and that country income categories do not measure household affordability.
