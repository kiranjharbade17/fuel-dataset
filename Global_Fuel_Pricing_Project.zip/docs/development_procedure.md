# Project development procedure

This procedure follows the SkillWallet project flow and describes what is implemented locally and what must still be completed.

## 1. Define the problem
Use the research question in `project_story.md`: how do weekly fuel prices vary by region and time, and how are observed prices associated with tax, income category, and subsidy category? The intended audiences are an energy policy consultant, a supply-chain manager, and an energy-economics researcher.

## 2. Collect and store the data
Use the supplied `data/global_fuel_prices_Dataset.csv`. It contains 27,468 rows, 10 source columns, 84 countries, 7 regions, and weekly dates from January 2020 to April 6, 2026.

To load the CSV into MySQL, run `sql/fuel_project_clean.sql` from the project root with `LOCAL INFILE` enabled in the client and server. The script creates the source table and a trimmed clean table, then runs row, country, date, and duplicate-key checks. The local Tableau workbook currently reads the CSV directly; switch Tableau to the database connection only after the SQL import has been completed and checked.

## 3. Prepare the data
The provided data has no missing values or duplicate country-week keys. Keep all ten source columns. No calculated columns or Tableau calculated fields are required. Use Tableau's existing Date hierarchy for Year filtering and standard aggregations such as AVG and COUNTD in views. Sort Date chronologically. Do not present extreme values or country mappings as independently verified against external sources; the supplied files do not establish that validation.

## 4. Build the visualizations
Follow `tableau_build_guide.md` for the KPI cards, petrol and diesel maps, four price trends, regional tax pie, highest-tax country bars, and top-three-country fuel comparison. The brief calls this nine types while listing ten views; the guide retains all ten listed views. The saved workbook currently has five starter sheets, so rebuild or add views to match the plan.

## 5. Assemble the dashboard
Add Country, Measure Names (Petrol/Diesel/LPG), and Year filters to the relevant sheets. Arrange the KPI cards, maps, trends, pie, and bars for a wide dashboard and check a narrow/mobile layout. Keep titles, units, source dates, and aggregation labels visible. Make chart selections filter other relevant views where useful.

## 6. Create the Tableau Story
Build seven Tableau Story points using the scenes in `project_story.md`: Introduction, Geographic Disparity, Temporal Trends, Taxation Policy, Economic Impact, Subsidy Assessment, and Conclusions and Recommendations. Add captions and limitations at the relevant scenes. In particular, mark 2026 as partial through April 6 and describe tax/subsidy relationships as associations, not causal effects.

## 7. Measure performance
The brief reports about 2.7 MB loaded in Tableau and responsive filters, but this has not been measured on the finished dashboard. Once the dashboard exists, record the workbook/data size, load time, filter response time, and whether all marks update correctly when Country, Measure Names, and Year filters are combined. Replace reported claims with the measurements you actually observe.

## 8. Publish to Tableau Public
Complete the steps in `tableau_public_publishing.md` after reviewing the finished workbook and its data. Copy the published Dashboard and Story URLs. The project is not currently published.

## 9. Embed in Flask
From the project root, follow `web/README.md` to install Flask and start the local site. Set `TABLEAU_DASHBOARD_URL` and `TABLEAU_STORY_URL` to the published view links. The Flask page shows setup placeholders until these URLs exist. The embedded content reflects the latest published data; it is not a live feed from this historical CSV.

## 10. Demonstrate and document
Use `demo_video_script.md` as a recording outline. Add screenshots, actual performance measurements, and Tableau Public links to the final documentation after the remaining work is complete. Git setup and submission are left for the project owner, as requested.
